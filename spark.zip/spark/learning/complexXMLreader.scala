package org.training.spark.learning

import org.apache.spark.sql.SQLContext
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.expressions.Window
/**
  * Created by hduser on 8/24/18.
  */
object complexXMLreader {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf().setMaster("local").setAppName("XML Reader")

    val sc = new SparkContext(conf)
    val sqlContext = new HiveContext(sc)
    val xmldf = sqlContext.read.format("xml")
      .option("rowtag", "book")
      .load("src/main/resources/books-nested-array.xml") // Nested xml file
     // .load("src/main/resources/books.xml")//complex xml file
    //xmldf.show()
    //xmldf.printSchema()

    //val flatdf = xmldf.withColumn("publish_date",explode(col("publish_date")))//publish date field
    //splitted in to new rows
    val flatdf = xmldf.withColumn("new_publish_date",explode(col("publish_date")))
                        .drop("publish_date")

    //flatdf.show()

    xmldf.registerTempTable("jay")//creating a temp table from dataframe

    val sqlflatdf = sqlContext.sql("select *,explode(publish_date) as new_publish_date from jay")

    sqlflatdf.show()

    sqlflatdf.registerTempTable("flattable")
    //val sqlversdf = sqlContext
      //.sql("select *,row_num() over (partition by title order by new_publish_date desc) as version from flattable")

    //sqlversdf.show()
    val versdf = flatdf.withColumn("version",row_number().over(Window.partitionBy("@id").orderBy(desc("new_publish_date"))))
                         .where("version=1").drop("version")
    //versdf.show()
  }


}
