package org.training.spark.learning

import java.util.Properties

import org.apache.spark.{SparkConf, SparkContext}

/**
  * Created by hduser on 8/28/18.
  */
object sparkjdbcreader {

  def main(args: Array[String]): Unit = {

    val sparkConf =  new SparkConf().setMaster("local").setAppName("Jdbc_reader")
    val sc: SparkContext = new SparkContext(sparkConf)
    val sqlContext = new org.apache.spark.sql.SQLContext(sc)
    val properties:Properties = new Properties()
    properties.setProperty("user","root")
    properties.setProperty("password","training")


    val jdbcprob = Map("url"->"jdbc:mysql://localhost:3306/ecommerce",
     // "dbtable" -> "sales", mentioning whole table name
           "dbtable" -> "(select * from sales where amountPaid > 500) as temp", // with where condition filtering data from source level.
      //alias is must here because another query run with where condition for 1=2 to get structure of the table.
      "user" -> "root","password" -> "training",
                      "partitioncolumn" -> "transactionId",
                       "lowerbound" -> "111","upperbound" -> "124","numpartitions" -> "4")
    val jdbcdf= sqlContext.read.format("jdbc").options(jdbcprob).load()
    //jdbcdf.write.mode("append").format("parquet").save("src/main/resources/parquet_output")
    // format("parquet") is a default. no need to mention.
    //jdbcdf.write.mode("append").format("csv").save("src/main/resources/")
    //jdbcdf.write.mode("overwrite").jdbc("jdbc:mysql://localhost:3306/ecommerce","salestest",properties)
    //.option("compression","snappy" or "gzip").mode("override").option("header","true")
    //.mode(safeMode.Append)


    // second method to load
    //jdbcdf.write.mode("append").parquet("src/main/resources/parquet_out2")

    jdbcdf.show()
    jdbcdf.printSchema()

    println(jdbcdf.rdd.getNumPartitions)


  }

}
