package org.training.spark.learning

import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.{SparkConf, SparkContext}

/**
  * Created by hduser on 8/30/18.
  */
object hiveintegration {

  def main(args: Array[String]): Unit = {
    val conf = new SparkConf().setAppName("Spark-hive").setMaster("local")
    val sc = new SparkContext(conf)
// default derby database. to change my sql use below properties. Required only if you run in local.
    System.setProperty("javax.jdo.option.ConnectionURL",
      "jdbc:mysql://localhost/hive_metastore?createDatabaseIfNotExist=true")
    System.setProperty("javax.jdo.option.ConnectionDriverName", "com.mysql.jdbc.Driver")
    System.setProperty("javax.jdo.option.ConnectionUserName", "root")
    System.setProperty("javax.jdo.option.ConnectionPassword", "training")
    System.setProperty("hive.metastore.warehouse.dir", "hdfs://localhost:54310/user/hive/warehouse")

    val hc = new HiveContext(sc)

    val csvdf = hc.read.format("csv")
                    .option("inferSchema","true")
                      .option("header","true")
                      .load("src/main/resources/sales.csv")

    csvdf.show()
    csvdf.printSchema()

    //csvdf.write.mode("append").format("orc").saveAsTable("training.sparktest")
      //.insertinto  wont create table
      // .saveastable will create table if not exists
      // when table already exists, have to use append mode.

   // hc.sql("select count(*) from training.sparktest").show()
// by sql method

    csvdf.registerTempTable("test")

  //  hc.sql("insert overwrite table training.sparktest select * from test")

    // by creating table method

    //hc.sql("create table training.testspark as select * from training.sparktest where 1=2")
//    hc.sql("insert into table training.testspark select * from test")


    // sql method
    hc.sql("create table if not exists training.itemid_partitioned " +
      "(transactionid int,customerid int,amountpaid double) partitioned by (itemid int)")
    hc.setConf("hive.exec.dynamic.partition","true")
    hc.setConf("hive.exec.dynamic.partition.mode","nonstrict")
    csvdf.registerTempTable("salesdata")

    hc.sql("insert into training.itemid_partitioned partition(itemid) select transactionid," +
      "customerid,amountpaid,itemid from salesdata")


    //Dataframe DSL API method

    //To create alias
    val renamedf = csvdf.selectExpr("transactionId as transactionid","customerId as customerid","itemId as itemid","amountPaid as amountpaid")
    renamedf.printSchema()

    renamedf.write.partitionBy("itemid").insertInto("training.itemid_partitioned")

  }


}
