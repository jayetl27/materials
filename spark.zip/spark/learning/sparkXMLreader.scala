package org.training.spark.learning

import org.apache.spark.sql.SQLContext
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.hive.HiveContext
/**
  * Created by hduser on 8/23/18.
  */
object sparkXMLreader {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf().setMaster("local").setAppName("XML Reader")

    val sc = new SparkContext(conf)
    val sqlContext = new HiveContext(sc)
        val xmldf = sqlContext.read.format("xml")
          .option("rowtag","person")
          .load("src/main/resources/ages.xml")
    xmldf.show()

    //xmldf.show()
    //xmldf.printSchema()
    import sqlContext.implicits._
    val newdf = xmldf.select(xmldf("age.#VALUE").as("ActualAge"),
      col("age.@born").alias("borndate"),$"name")
      //newdf.show()
    //newdf.printSchema()
    val aggdf = newdf.groupBy("ActualAge").count()
    aggdf.show()
     val catdf = newdf.withColumn("age_category",when(col("ActualAge") <= 20,"youth").otherwise("adult"))
      .withColumnRenamed("ActualAge","age")

    //catdf.show()
    val rnmalldf = catdf.selectExpr("age as age",
    "borndate as birthdate","name as fullname","age_category as age_category")
    //rnmalldf.show()

    val multiaggdf = rnmalldf.groupBy("age").agg(count("age"),collect_list("fullname"))
    multiaggdf.show()

  }

}































