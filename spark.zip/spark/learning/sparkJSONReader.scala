package org.training.spark.learning

import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.hive.HiveContext
import org.apache.spark.sql.types._

/**
  * Created by hduser on 8/25/18.
  */
object sparkJSONReader {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf().setMaster("local").setAppName("CSV Reader")

    val sc = new SparkContext(conf)
    val sqlContext = new HiveContext(sc)

    val schema = StructType(Array(
      StructField("tid",LongType,true),
      StructField("cid",LongType,true),
      StructField("itid",IntegerType,true),
      StructField("price",DoubleType,true)
    ))

    val jsondf = sqlContext.read.format("csv")
        //.option("Header","true")
        .option("mode","DROPMALFORMED")
      .schema(schema)
      .load("src/main/resources/sales.csv")

    jsondf.show()
    jsondf.printSchema()

  }

}
