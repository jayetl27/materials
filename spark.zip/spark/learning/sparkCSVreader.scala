package org.training.spark.learning

import org.apache.spark.sql.SQLContext
import org.apache.spark.{SparkConf, SparkContext}

/**
  * Created by hduser on 8/23/18.
  */
object sparkCSVreader {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf().setMaster("local").setAppName("CSV Reader")

         val sc = new SparkContext(conf)
        val sqlContext = new SQLContext(sc)
        val optionsMap = Map("inferschema" -> "true", "delimiter" -> "|")
        val csdf = sqlContext.read.format("csv")
          .options(optionsMap)
          //.option("header","false")
          //.option("inferschema","true")
          //.option("delimiter","|")
          .load("src/main/resources/sales-noheader.csv")

        csdf.show()
        csdf.printSchema()
      }

    }