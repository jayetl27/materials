package org.training.spark.learning

import org.apache.spark.{SparkConf, SparkContext}
import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.functions._

/**
  * Created by hduser on 8/31/18.
  */
object sparkUDF {

  def main(args: Array[String]): Unit = {

    val conf = new SparkConf().setMaster("local").setAppName("Spark UDF example")

    val sc = new SparkContext(conf)
    val sqlContext = new SQLContext(sc)
    val optionsMap = Map("inferschema" -> "true")
    val csdf = sqlContext.read.format("csv")
      .options(optionsMap)
      .option("header","true")
      //.option("inferschema","true")
      //.option("delimiter","|")
      .load("src/main/resources/sales.csv")

    val caldisprice = udf((price:Double)=> {

      price*0.9
    }
    )
    val finaldf = csdf.withColumn("discountedamount",caldisprice(col("amountPaid")))

    finaldf.show()
     //sql method
    sqlContext.udf.register("computeddis",(price:Double)=> {

      price*0.9
    })
csdf.registerTempTable("test")
    val sqldf = sqlContext.sql("select *,computeddis(amountPaid) as dis from test")

    sqldf.show()
    //csdf.show()
    //csdf.printSchema()
  }


}
