package org.training.spark.utils

/**
 * Created by hduser on 25/2/15.
 */
case class Sales(transactionId:Int,customerId:Int,itemId:Int,amountPaid:Double)
