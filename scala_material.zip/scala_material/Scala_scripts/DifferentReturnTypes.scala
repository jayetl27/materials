def add(x:Int, y:Int) = x + y
def subtract(x:Int, y:Int) = x - y

println(add(subtract(10,5), subtract(100,32)))

def sum(x:Int, y:Int) = {
 if(x > 10) (x+y).toString
 else x + y
}

println(sum(4,10))