val result = (1 to 100).reverse.mkString(",") // more of functional way without any vars (mutable state)

println(result)

// println((100 to 1 by -1).mkString(","))