val e = new Employee("Arjun", "T")
println(e)
println(e.firstName)
e.lastName = "Trainer"
println(e.lastName)
println(e.title)

val d = Department("CSE")
println(d)
println(d.name)