val a = 99
println(s"$a ballons floating in the summer sky")
// println(s"${a} ballons floating in the summer sky")
// println(s"$a + 3 ballons floating in the summer sky")
// println(s"${a + 3} ballons floating in the summer sky")

val ticketCost = 50
val bandName = "Band"
// f interpolater (interpolation + formatting)
println(f"The $bandName%s tickets are probably $$$ticketCost%.2f")

println("This is a test %s".format("script"))
val str = String.format("Java-style : This is a test %s", "script")
println(str)

val percentIncrease = 20
val musicGenre = "New wave"
println(f"The $bandName%s tickets are probably $$$ticketCost%.2f%nThat's a $percentIncrease%% bump because everyone likes $musicGenre")



