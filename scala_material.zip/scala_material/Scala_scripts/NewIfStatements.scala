val a = 10

// try to avoid vars
val result = if (a < 10) "Less than 10!"
	     else if (a > 10) "Greater that 10!"
	     else "It is 10!"
// above is inline and avoid mutable updates (more of functional)

println(result)