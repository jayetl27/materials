val l = List(1,2,3,4)
val result = for(a <- l) yield (a+1) // for comprehension (immutability in terms of val)

println(result)
println(l)