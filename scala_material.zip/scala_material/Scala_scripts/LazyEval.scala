//val a = b + 10
//val b = 20
//print(a)

lazy val a = b + 10
lazy val b = 20
print(a)