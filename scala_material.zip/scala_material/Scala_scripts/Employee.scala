class Employee(val firstName:String, var lastName:String, val title:String) {

	def this(firstName:String, lastName:String) = {this(firstName, lastName, "Scala")}
	
	def this(firstName:String) = this(firstName, "Unknown", "Scala")
}

case class Department(name:String)