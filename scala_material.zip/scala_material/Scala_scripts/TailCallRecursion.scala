import scala.annotation.tailrec

@tailrec
//@scala.annotation.tailrec
def factorial(n:BigInt, acc:BigInt):BigInt = {  // try with BigInt
 if(n == 0 || n == 1) acc
 else factorial(n-1, acc * n)
}

//def factorial(n:Int) = fact(n,1)

//println(factorial(5,1))
//println(factorial(100,1))
//println(factorial(1000,1))
//println(factorial(10000,1))
println(factorial(100000,1))