var a = 0
def sideEffect() {
 a = a + 1
}

//sideEffect
println(a)