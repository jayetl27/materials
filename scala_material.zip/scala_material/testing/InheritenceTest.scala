package testing

/**
  * Created by sumantht on 5/29/2017.
  */
class A {
  var a = 10
  private val b = 10
  protected val c = 20
  def method1() = println("I am in Class A method1 and value of a is:"+a)
  def method() = println("I am in Class A method")
}

class B extends A {
  a = 20
  override def method1(): Unit = println("I am in Class B method1 and value of a is"+a)
  def method2 = println("I am in Class B method2 and value of c is"+c)
}

class C extends B {
  println(c)
}

object InheritenceTest extends App {

  val bObj = new B()
  println(bObj.a)
  bObj.method1()
  bObj.method()

  val aObj = new A
  println(aObj.a)
  aObj.method1()

  val cObj = new C
  cObj.method1()

}
