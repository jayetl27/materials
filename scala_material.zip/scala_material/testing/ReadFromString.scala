package testing

import scala.io.Source
/**
  * Created by sumantht on 5/16/2017.
  */
object ReadFromString {

  def main(args: Array[String]) {

    println(args(0))

    case class Employee(name: String, deptname: String)

    val lst = new scala.collection.mutable.ListBuffer[Employee]

    val string = Source.fromString(
      """Sumanth,DSG
         Anand,DSG
      """)

    val rowIterator = string.getLines()

    for (i <- rowIterator) {
      val cols = i.split(",")
      lst += Employee(cols(0), cols(1))
    }

  }

}
