package org.training.scala

import scala.math.Ordering

/**
 * Created by pramod on 14/1/16.
 */
object mergesort2 {

  def msort[T](lt: (T, T) => Boolean)(xs: List[T]): List[T] = {
    val n = xs.length/2
    if (n == 0) xs
    else {
      def merge(xs: List[T], ys: List[T]):List[T] = (xs, ys) match  {
        case (xs, List()) => xs
        case (List(), ys) => ys
        case (x :: xs1, y :: ys1) =>
          if (lt(x, y)) x :: merge(xs1, ys) else y :: merge(xs, ys1)
      }
      val (fst, snd) = xs.splitAt(n)
      merge(msort(lt)(fst), msort(lt)(snd))
    }
  }

  def main(args: Array[String]) {
    val list = List(1, -5, 2, -9, 3, 8)

    val intSort = msort((x: Int, y:Int) => x < y)_
    val sortedList = intSort(list)
    sortedList.foreach(println)

    val reverseIntSort = msort((x: Int, y:Int) => x > y)_
    val reverseSortedList = reverseIntSort(list)
    reverseSortedList.foreach(println)

    val words = List("one", "two", "three", "four", "six")
    val stringSort = msort((x: String, y:String) => x.compareTo(y) < 0)_
    val sortedWords = stringSort(words)
    sortedWords.foreach(println)
    val sBy = words.sortBy(_.length)
    val sSorted = words.sorted
    val sWith = words.sortWith(_ < _)


    val tup2 = List((1, "one"), (2, "two"), (3, "three"), (4, "four"))
    //sort by length of the string
    val mixSortBy = tup2.sortBy(_._2.toString.length)
    //sort by length of the string
    val mixCaseSortBy = tup2.sortBy{case (x, y ) => y.toString.length}
    mixCaseSortBy.foreach(println)

    val items = List((9, "Beta"), (3, "Zeta"), (1, "Gamma"), (5, "Alpha"), (2, "Beta"), (3, "Gamma"))
    //sort by second field in the desc order
    println(items.sortWith{case ((_, s1), (_, s2)) => s2.compareTo(s1) < 0})

    //sort by second field in the asc order
    println(items.sortBy(_._2))

    //sort by second field in the desc order
    implicit object osRev extends Ordering[String] { def compare(a: String, b: String): Int = b compare a}

    println(items.sortBy(_._2))

  }
}
