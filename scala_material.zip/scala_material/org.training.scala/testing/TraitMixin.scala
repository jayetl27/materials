package org.training.scala.testing

/**
  * Created by sumantht on 4/24/2017.
  */
trait Tail {
  def wagTail { println("tail is wagging") }
}

abstract class Pet (var name: String) {
  def speak  // abstract
  def ownerIsHome { println(s"$name is excited") }
}

class Dog (name: String) extends Pet (name) with Tail {
//class Dog (name: String) ___________________ {
  def speak { println("woof") }
}

object TraitMixin extends App {
  val zeus = new Dog("Zeus")
  zeus.ownerIsHome
  zeus.wagTail
  zeus.speak
}
