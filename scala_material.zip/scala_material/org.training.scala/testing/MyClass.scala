package org.training.scala.testing

/**
  * Created by sumantht on 4/26/2017.
  */
class MyClass(number: Int, text: String) {

  private val classSecret = 42

  def x = MyClass.objectSecret + "?" // MyClass.objectSecret is accessible because it's inside the class. External classes/objects can't access it
}

object MyClass { // it's a companion object because it has the same name
private val objectSecret = "42"

  def y(arg: MyClass) = arg.classSecret -1 // arg.classSecret is accessible because it's inside the companion object
}

/*
object test extends App {
  MyClass.objectSecret // won't compile
  MyClass.classSecret // won't compile

  new MyClass(-1, "random").objectSecret // won't compile
  new MyClass(-1, "random").classSecret // won't compile
}*/
